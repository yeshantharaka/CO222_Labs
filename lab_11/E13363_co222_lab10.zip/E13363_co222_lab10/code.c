#include <stdio.h>
#include <stdlib.h>
void print();
void insert_record();
void search();
void search_all();
void delete();

typedef struct _{              // make aray thay have many variables to get details. 
		int batch;
		int reg_no;
		char first_name[20];
		char last_name[20];
		float cgpa;
		struct _ *next;
}insert;
	
insert *details;
insert *first;
insert *first1;
insert *first2;
insert *first3;
insert *previus;

int main() {
	details= (insert *)malloc(sizeof(insert));
	first=details;
	first1=details;
	first2=details;
	first3=details;
	previus=first3;
	int a;
	
	int input;
	for(a=0; ;a++){
		print();              // call function to print instruction
		scanf("%d",&input);     // get the input that user want to do
		
		if(input==1){
			insert_record();     // call function to insert details
			insert *s = (insert *)malloc(sizeof(insert));
			details -> next = s;
			details=details->next;
			
		} else if(input==0){
			break;                     // end the running when user need
		} else if(input==2){
			search();                  // call the function to search one detail
		} else if(input==3){
			search_all();        // call the function to print all details
		} else if(input==4){
			delete();                  // call the function to delete details
			
		}
		
		
	}	
	
	return 0;
}

void print(){                                              // function to print instruction
	printf("--------------------------------------------\n");
	printf("A VOLATILE STUDENT RECORD MAINTENANCE SYSTEM\n");
	printf("--------------------------------------------\n");
	printf("0. Quit\n");
	printf("1. Insert a Student Record\n");
	printf("2. Print a Student Record\n");
	printf("3. Print all Student Records\n");
	printf("4. Delete a Student Record\n");
	
}

void insert_record(){                   // function to enter the details
	
	
	printf("Enter the batch (11/12/13/14): ");
	scanf("%d",&details->batch);
			
	printf("Enter the registration number: ");
	scanf("%d",&details->reg_no);
			
	printf("Enter the first name: ");
	scanf("%s",details->first_name);
			
	printf("Enter the last name: ");
	scanf("%s",details->last_name);
			
	printf("Enter the cumulative GPA: ");
	scanf("%f",&details->cgpa);
		
}

void search(){                    // function to seach one person
	
	int a;
	printf("Enter the registration number: ");
	scanf("%d",&a);
	
	while(first1->next!=NULL){
		if(first1->reg_no==a){
			printf("The student %s %s (E/%d/%d) has cumulative GPA of %.2f\n",first1->first_name,first1->last_name,first1->batch,first1->reg_no,first1->cgpa);
		} else{
		}
		first1=first1->next;
	}
	first1=first;
}

void search_all(){                  // function to print all details
	
	while(first2->next!=NULL){
		printf("The student %s %s (E/%d/%d) has cumulative GPA of %.2f\n",first2->first_name,first2->last_name,first2->batch,first2->reg_no,first2->cgpa);
		first2=first2->next;
	}
	first2=first;
}


void delete(){          // function to delete 
	int a;
	
	printf("Enter the registration nuber: ");
	scanf("%d",&a);
	
	while(first3->next!=NULL){
		if(first3->reg_no==a){
			break;
		} else{
			previus=first3;
			first3=first3->next;
			
		}
	}
	previus->next=first3->next;
	first3=first;
	
}
