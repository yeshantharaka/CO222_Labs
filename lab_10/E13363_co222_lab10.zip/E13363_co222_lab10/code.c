#include <stdio.h>
void print();
void insert_record(int a);
void search();
void search_all(int a);
void delete();

typedef struct _ {              // make aray thay have many variables to get details. 
		int batch;
		int reg_no;
		char first_name[20];
		char last_name[20];
		float cgpa;
	}insert;
	
insert details[1000];

int main() {
	int a;
	print();              // call function to print instruction
	int count1=0;
	int input;
	for(a=0;a<=999;a++){
		scanf("%d",&input);     // get the input that user want to do
		
		if(input==1){
			insert_record(count1);     // call function to insert details
			count1++;
		} else if(input==0){
			break;                     // end the running when user need
		} else if(input==2){
			search();                  // call the function to search one detail
		} else if(input==3){
			search_all(count1);        // call the function to print all details
		} else if(input==4){
			delete();                  // call the function to delete details
			count1--;
		}
		
		
	}	
	
	return 0;
}

void print(){                                              // function to print instruction
	printf("--------------------------------------------\n");
	printf("A VOLATILE STUDENT RECORD MAINTENANCE SYSTEM\n");
	printf("--------------------------------------------\n");
	printf("0. Quit\n");
	printf("1. Insert a Student Record\n");
	printf("2. Print a Student Record\n");
	printf("3. Print all Student Records\n");
	printf("4. Delete a Student Record\n");
	
}

void insert_record(int a){                   // function to enter the details
	
	
	printf("Enter the batch (11/12/13/14): ");
	scanf("%d",&details[a].batch);
			
	printf("Enter the registration number: ");
	scanf("%d",&details[a].reg_no);
			
	printf("Enter the first name: ");
	scanf("%s",details[a].first_name);
			
	printf("Enter the last name: ");
	scanf("%s",details[a].last_name);
			
	printf("Enter the cumulative GPA: ");
	scanf("%f",&details[a].cgpa);
		
}

void search(){                    // function to seach one person
	int a,b;
	printf("Enter the registration number: ");
	scanf("%d",&a);
	
	for(b=0;b<=999;b++){
		if(details[b].reg_no==a){
			printf("The student %s %s (E/%d/%d) has cumulative GPA of %.2f\n",details[b].first_name,details[b].last_name,details[b].batch,details[b].reg_no,details[b].cgpa);
		} else{
		}
	}
	
}

void search_all(int a){                  // function to print all details
	int b;
	for(b=0;b<=(a-1);b++){
		printf("The student %s %s (E/%d/%d) has cumulative GPA of %.2f\n",details[b].first_name,details[b].last_name,details[b].batch,details[b].reg_no,details[b].cgpa);
	}
}


void delete(){          // function to delete 
	int a,b,c;
	int count=0;
	printf("Enter the registration nuber: ");
	scanf("%d",&a);
	
	for(b=0;b<=999;b++){
		if(details[b].reg_no==a){
			break;
		} else{
			count++;
		}
	}
	for(c=(count+1);c<=999;c++){
		details[(c-1)]=details[c];
	}
	
}
